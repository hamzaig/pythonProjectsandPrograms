==================
Command line tools
==================

ChatterBot comes with a few command line tools that can help

Get the installed ChatterBot version
====================================

If have ChatterBot installed and you want to check what version
you have then you can run the following command.

.. code-block:: bash

   python -m chatterbot --version
